#!/bin/bash

# Start the Flask app directly
export FLASK_APP=app.py
export FLASK_ENV=production
python -m flask run --host=0.0.0.0 --port=8000
