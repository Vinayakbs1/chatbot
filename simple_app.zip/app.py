from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return "Hello, World! This is the Career Guidance Chatbot."

@app.route('/chat')
def chat():
    return "Chat functionality will be integrated here."

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
